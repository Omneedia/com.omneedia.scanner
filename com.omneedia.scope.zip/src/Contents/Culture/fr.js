i18n['fr'] = {	
	region  : "Bonjour le monde !"
};