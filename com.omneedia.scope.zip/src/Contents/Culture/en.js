i18n['en'] = {	
	region  : "Hello World!"
};