Settings = {
    "DEBUG": true,
    "NAMESPACE": "com.omneedia.scope",
    "TITLE": "OmneediaScope",
    "DESCRIPTION": "Test your app build with omneedia Framework in real device",
    "COPYRIGHT": "Copyright (c) 2015 By OMNEEDIA",
    "TYPE": "mobile",
    "LANGS": [
        "en",
        "fr"
    ],
    "AUTH": {
        "passports": [],
        "passport": {}
    },
    "FRAMEWORKS": [
        "http://cdn.sencha.io/touch/sencha-touch-2.4.1/sencha-touch-all-debug.js",
        "http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.js"
    ],
    "RESOURCES": [
        "http://cdn.sencha.io/touch/sencha-touch-2.4.1/resources/css/cupertino.css",
        "http://omneedia.github.io/cdn/omneedia/res/mobi.css",
        "Contents/Resources/mobi.css"
    ],
    "LIBRARIES": [],
    "PATHS": {
        "Contents": "Contents/Application/app",
        "Culture": "Contents/Culture",
        "omneedia": "http://omneedia.github.io/cdn/omneedia",
        "Ext.ux": "http://omneedia.github.io/cdn/ext/ux",
        "Ext.plugin": "http://omneedia.github.io/cdn/ext/plugin",
        "Ext.util": "http://omneedia.github.io/cdn/ext/util"
    },
    "CONTROLLERS": [
        "CMain"
    ],
    "MODULES": [
        "omneedia.Localizer",
        "omneedia.App",
        "omneedia.Auth",
        "omneedia.FS"
    ],
    "AUTHORS": [
        {
            "role": "creator",
            "name": "Stéphane Zucatti",
            "mail": "stephane.zucatti@me.com",
            "twitter": "@mydearsz",
            "web": "",
            "github": ""
        }
    ],
    "API": [
        "__QUERY__",
        "MyService"
    ],
    "VERSION": "1.00",
    "BUILD": 80,
    "BUILD_DATE": "2015-06-15T14:06:25.682Z"
}