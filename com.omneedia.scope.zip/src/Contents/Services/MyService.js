
MyService = {
	hello: function(o,cb) {
		cb('hello world '+o);
	}
}

module.exports = MyService;
