App.view.define('Viewport', 
{
	
    extend: 'Ext.container.Viewport',

	requires: [

    ],
	
    config: {
	
		fullscreen: true,
		layout: {
			type: "card"
		},
		items: [

		]
		
	}
	
});